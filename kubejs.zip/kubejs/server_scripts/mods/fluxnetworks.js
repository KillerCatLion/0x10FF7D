onEvent("recipes", (event) => {
  event.recipes.mekanismMetallurgicInfusing(
    "fluxnetworks:flux_dust",
    "mekanism:dust_obsidian",
    "mekanism:redstone",
    10
  );
});
