ServerEvents.recipes(e =>{
    e.remove({id: 'reliquary:rod_of_lyssa'})
})