// priority: 99
onEvent("recipes", (event) => {
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "clay",
    url: "https://cdn.discordapp.com/emojis/699724453541707887.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "ftb",
    url: "https://cdn.discordapp.com/emojis/372788696128290817.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "kevHappy",
    url: "https://cdn.discordapp.com/emojis/898721842238468166.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "kevStonk",
    url: "https://cdn.discordapp.com/emojis/898718212475207691.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "unknown",
    url: "https://cdn.discordapp.com/emojis/856626885827100672.png",
  });
});
