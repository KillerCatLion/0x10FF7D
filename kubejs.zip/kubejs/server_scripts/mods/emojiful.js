// priority: 99
onEvent("recipes", (event) => {
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "clay",
    url: "https://cdn.discordapp.com/emojis/699724453541707887.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "ftb",
    url: "https://cdn.discordapp.com/emojis/372788696128290817.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "kevHappy",
    url: "https://cdn.discordapp.com/emojis/898721842238468166.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "kevStonk",
    url: "https://cdn.discordapp.com/emojis/898718212475207691.png",
  });
  event.recipes.emojiful.emoji_recipe({
    category: "FTB",
    name: "unknown",
    url: "https://cdn.discordapp.com/emojis/856626885827100672.png",
  });
  event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaBox",url: "https://cdn.discordapp.com/emojis/817909791859015731.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaWink",url: "https://cdn.discordapp.com/emojis/643747916179177472.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaSuika~1",url: "https://cdn.discordapp.com/emojis/989503432400461855.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaIgnorework",url: "https://cdn.discordapp.com/emojis/986473183009980426.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaLove",url: "https://cdn.discordapp.com/emojis/661665923043688469.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasCry",url: "https://cdn.discordapp.com/emojis/733017037525483631.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaPizza",url: "https://cdn.discordapp.com/emojis/637718993305862211.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaPurrito",url: "https://cdn.discordapp.com/emojis/722195329373569024.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSurrender",url: "https://cdn.discordapp.com/emojis/1044939099473182720.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaCool",url: "https://cdn.discordapp.com/emojis/706107989047771239.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "zzmilklove2~1",url: "https://cdn.discordapp.com/emojis/893317213140975618.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "zwmmbonk",url: "https://cdn.discordapp.com/emojis/768489063257866250.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaEat",url: "https://cdn.discordapp.com/emojis/649465449473376272.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "zumilklove2",url: "https://cdn.discordapp.com/emojis/765175347138134016.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "BearCrying",url: "https://cdn.discordapp.com/emojis/590109064961327124.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaLove1",url: "https://cdn.discordapp.com/emojis/568124063910985749.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaPinch",url: "https://cdn.discordapp.com/emojis/638690802956238853.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaClover",url: "https://cdn.discordapp.com/emojis/694973517921255556.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "zrmmhit",url: "https://cdn.discordapp.com/emojis/765175088383131669.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSuika",url: "https://cdn.discordapp.com/emojis/989503434657005588.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasHug1",url: "https://cdn.discordapp.com/emojis/568124063520915456.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaBrush",url: "https://cdn.discordapp.com/emojis/637712788906573855.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaCheer",url: "https://cdn.discordapp.com/emojis/1044939045450563634.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaCold",url: "https://cdn.discordapp.com/emojis/1044939607759925348.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaCozy1",url: "https://cdn.discordapp.com/emojis/817909791287934986.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "zrmmleaned",url: "https://cdn.discordapp.com/emojis/765175088864559114.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaHyperspin",url: "https://cdn.discordapp.com/emojis/781244106910334996.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasCuddle",url: "https://cdn.discordapp.com/emojis/938677320074555412.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaParty",url: "https://cdn.discordapp.com/emojis/1044939069060292608.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaFlowers",url: "https://cdn.discordapp.com/emojis/679796247967563872.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaBreakfast",url: "https://cdn.discordapp.com/emojis/986477000980070430.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasHug8",url: "https://cdn.discordapp.com/emojis/649460291049881601.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaDraw",url: "https://cdn.discordapp.com/emojis/1044939049074429962.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaBored2",url: "https://cdn.discordapp.com/emojis/733017032236204032.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaBoba~1",url: "https://cdn.discordapp.com/emojis/683860865925251139.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasBite2",url: "https://cdn.discordapp.com/emojis/677529302043983893.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaFlower",url: "https://cdn.discordapp.com/emojis/732175276724977765.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "milksit",url: "https://cdn.discordapp.com/emojis/840618856266465340.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaAttack",url: "https://cdn.discordapp.com/emojis/568124063675973632.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "Milkcwy",url: "https://cdn.discordapp.com/emojis/783493277575020554.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaBoba2",url: "https://cdn.discordapp.com/emojis/817909791686656010.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "zrmmpull3",url: "https://cdn.discordapp.com/emojis/765175088940318740.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaShiba",url: "https://cdn.discordapp.com/emojis/706107989169274961.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSneeze",url: "https://cdn.discordapp.com/emojis/986470583527170118.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaHyperyay",url: "https://cdn.discordapp.com/emojis/679796248819138561.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSit",url: "https://cdn.discordapp.com/emojis/643747914719428608.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSpin",url: "https://cdn.discordapp.com/emojis/687556650525261847.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaTearsbowl",url: "https://cdn.discordapp.com/emojis/638690801806999552.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaLovepls",url: "https://cdn.discordapp.com/emojis/661665923777953812.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaPurrito",url: "https://cdn.discordapp.com/emojis/722195328564199495.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaThink",url: "https://cdn.discordapp.com/emojis/643643324280078336.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaChips~1",url: "https://cdn.discordapp.com/emojis/733017032194392196.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaComfy",url: "https://cdn.discordapp.com/emojis/823189950928257025.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaWork",url: "https://cdn.discordapp.com/emojis/661665921097531392.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaNod",url: "https://cdn.discordapp.com/emojis/683860866814574673.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaTexts",url: "https://cdn.discordapp.com/emojis/733017036308873316.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaBaby3",url: "https://cdn.discordapp.com/emojis/817909790788288533.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSit2",url: "https://cdn.discordapp.com/emojis/817916054441033748.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasPlayful5",url: "https://cdn.discordapp.com/emojis/677529302157492224.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaLooking",url: "https://cdn.discordapp.com/emojis/638690801496358914.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaLook",url: "https://cdn.discordapp.com/emojis/733017023868829797.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaChick",url: "https://cdn.discordapp.com/emojis/820841750989504532.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaBurger",url: "https://cdn.discordapp.com/emojis/694973516444991619.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaTease1",url: "https://cdn.discordapp.com/emojis/571243416932057089.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "02study",url: "https://cdn.discordapp.com/emojis/779319462641270785.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaTears2",url: "https://cdn.discordapp.com/emojis/733017034170040440.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaMeow",url: "https://cdn.discordapp.com/emojis/817909790978080768.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasHug6",url: "https://cdn.discordapp.com/emojis/677529301998108691.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasBully6",url: "https://cdn.discordapp.com/emojis/820161342706941971.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaBaby",url: "https://cdn.discordapp.com/emojis/683860866071789683.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasHangingout",url: "https://cdn.discordapp.com/emojis/677529298839535616.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaNod2",url: "https://cdn.discordapp.com/emojis/644108416515571722.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "0p_catkiss",url: "https://cdn.discordapp.com/emojis/1009420012810940477.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaTired",url: "https://cdn.discordapp.com/emojis/568124062488854538.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaMhm",url: "https://cdn.discordapp.com/emojis/638690801206951936.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaPat",url: "https://cdn.discordapp.com/emojis/661665923941269517.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaWave",url: "https://cdn.discordapp.com/emojis/733017035658756187.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaPoint",url: "https://cdn.discordapp.com/emojis/706107988968079420.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSnow",url: "https://cdn.discordapp.com/emojis/1044939624071565373.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaThumbsup",url: "https://cdn.discordapp.com/emojis/661665924520345605.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaKFC",url: "https://cdn.discordapp.com/emojis/986468898247430164.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaFlowers",url: "https://cdn.discordapp.com/emojis/679796247971758180.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSleep2",url: "https://cdn.discordapp.com/emojis/649465450509631508.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyasKiss7",url: "https://cdn.discordapp.com/emojis/677529301297397770.gif?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaaThink",url: "https://cdn.discordapp.com/emojis/1044939035656847400.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaChicks",url: "https://cdn.discordapp.com/emojis/820841751006150685.webp?size=80&quality=lossless",});
event.recipes.emojiful.emoji_recipe({category: "Lexi",name: "nyaSleep1",url: "https://cdn.discordapp.com/emojis/637712789531525130.gif?size=80&quality=lossless",});
});
