ServerEvents.recipes(event => {
    event.remove({ id: 'ars_nouveau:glyph_animate_block'})
})
