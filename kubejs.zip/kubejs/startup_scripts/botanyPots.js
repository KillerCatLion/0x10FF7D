/*
    Crops grown in Botany Pots will trigger Forge's Crop Grow Event
    Trees grown in Botany Pots will trigger Forge's Sapling Grow Tree Event
    basically adds 'compat' for Ars' Agronomic Sourcelink
    authored by EnigmaQuip
*/

/// Deleted due to bug
