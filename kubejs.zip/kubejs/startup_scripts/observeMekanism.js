// moved to client_scripts
// file maintained for overwriting existing installations